# Blendup Press Kit

This press kit contains all the necessary assets and information for media and press inquiries about Blendup.

## Contents

- `logos/` - Brand logos in various formats
- `screenshots/` - App screenshots and mockups
- `team/` - Team photos and bios
- `documents/` - Company overview and press materials

## Usage

Please use the assets in this kit for press and media purposes only. For any other uses, please contact press@blendup.com.

## Contact

For media inquiries, please contact:
- Email: press@blendup.com
- Phone: +91 1234567890
